﻿define s = Character("Socks")
define a = Character("You")
define d = Character("Narrator")
define c = Character("CONTENT WARNING")
define f = Character("Ken")
define f2 = Character("Ken, Today")
label start:

    s "The world is strange"
    s "Someone wants to die one day"
    s "But there fine the next!"
    s "This is how i died"
    s "how i became a ghost"
    a "oh yay I love stories!!"
    s "oh yeah, if your under 18 veiwer discression is advised"
    a "oh, but im seven"
    d "We got em boys!!!!"
    d "pls don't read on if your a child!!!"
    d "Oh yeah CONTENT WARNING"
    c "This game contains depictions of: depressions, sexual abuse, child abuse, animal abuse,suicide, etempted suicide, bullying, gay (dont ask they made me put this here), gay sex, drugs, alchahol, abuse, and yeah thats it, Sorry but the story is great!! :D!"
    d "5th May 2019, Socks is walking to school"
    f "u ok socks??? u have been down from like January??? wtf"
    s "lol, im fine!!"
    f "why tf are we texting??"
    f "ur like 20cm way frm me lol!"
    f "Socks!!"
    f2 "I looked back and..."
    s "a guy had stabbed me 10 times in my back with a machete"
    f2 "FUCK! It was fucking horrible!!"
    f2 "YOU ALMOST FUCKING DIED!! IF I WASN'T FUCKING THERE YOU WOULD HAVE DIED IN THE FIRST FUCKING MOMENTS OF THIS GAME!!"
    s "the moments i wanted to fucking die lol!"
    f2 "LOL, FUCKING LOL, I SAVED YOUR FUCKING LIFE YOU UNGREATFUL ASSHOLE!!!!!"
    s "pfffff"
    
    return